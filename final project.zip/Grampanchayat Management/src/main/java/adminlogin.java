import java.sql.*;
import java.io.*;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SLserver
 */
@WebServlet("/adminlogin")
public class adminlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminlogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection ("jdbc:mysql://localhost/grampanchayat","root","");
			String Number =request.getParameter("id");
			String Pass =request.getParameter("pass");
			PreparedStatement ps=con.prepareStatement("Select Contact_Number from nuser where Contact_Number=? and Password=?;");
			ps.setString(1, Number);
			ps.setString(2, Pass);
			ResultSet rs =ps.executeQuery();	
			if(rs.next()) 
			{
				response.sendRedirect("Index3Admin.html");
				//RequestDispatcher rd =request.getRequestDispatcher("Index2User.html");
				//rd.forward(request,response);
			} 
			else
			{		
				pw.println("Sorry ! You Entered Wrong Mobile number Or Password.<br> Please Try Again!! ");
				//RequestDispatcher rd =request.getRequestDispatcher("Stu_L.html");
				//rd.include(request,response);
			}
			con.close();
		}
		catch (Exception e)
		{
		System.out.println(e);
		}
	}
}
