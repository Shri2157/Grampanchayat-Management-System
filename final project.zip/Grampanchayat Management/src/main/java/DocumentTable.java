

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class emp
 */
@WebServlet("/DocumentTable")
public class DocumentTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DocumentTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection ("jdbc:mysql://localhost:3306/grampanchayat","root","");
		Statement stmt=con.createStatement ();
		String Document_Name=request.getParameter("nm");
		String Document_Details=request.getParameter("dd");
		String date=request.getParameter("dt");
		String Aadhar_Number=request.getParameter("cy");
		String s;
		s="INSERT INTO `document_table`(`Document_name`, `Document_details`, `Date`, `Aadhar_Number`) VALUES ('"+Document_Name+"','"+Document_Details+"','"+date+"','"+Aadhar_Number+"')";
		int i=stmt.executeUpdate(s);
		System.out.println(i+" Record Added");
		RequestDispatcher rd =request.getRequestDispatcher("submit.html");
		rd.forward(request,response);
		
		con.close();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		}

}
