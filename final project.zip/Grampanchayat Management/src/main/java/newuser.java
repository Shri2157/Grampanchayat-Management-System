

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class emp
 */
@WebServlet("/newuser")
public class newuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public newuser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection ("jdbc:mysql://localhost:3306/grampanchayat","root","");
		Statement stmt=con.createStatement ();
		String Aadhar_Number=request.getParameter("id");
		String Name=request.getParameter("nm");
		String DOB=request.getParameter("dob");
		String Email_ID=request.getParameter("email");
		String Contact_NO=request.getParameter("mobile");
		String Address=request.getParameter("ad");
		String Gender=request.getParameter("Gender");
		String Password=request.getParameter("pass");
		String s;
		s="insert into nuser (Aadhar_Number,Name,DOB,Email_ID,Contact_Number,Address,Gender,Password) values('"+Aadhar_Number+"','"+Name+"','"+DOB+"','"+Email_ID+"','"+Contact_NO+"','"+Address+"','"+Gender+"','"+Password+"')";
		int i=stmt.executeUpdate(s);
		System.out.println(i+" Record Added");
	//	RequestDispatcher rd =request.getRequestDispatcher("submit.html");
	//	rd.forward(request,response);
		
		con.close();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		}

}
