

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class emp
 */
@WebServlet("/applyscheme")
public class applyscheme extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public applyscheme() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection ("jdbc:mysql://localhost:3306/grampanchayat","root","");
		Statement stmt=con.createStatement ();
		String Aadhar=request.getParameter("id");
		String Scheme_Name=request.getParameter("nm");
		String Scheme_Details=request.getParameter("st");
		String Date_From=request.getParameter("pt");
		String Date_To=request.getParameter("ad");
		String s;
		s="INSERT INTO `scheme_table`(`Aadhar_Number`, `Scheme_Name`, `Scheme_Details`, `Date_from`, `Date_to`) VALUES ('"+Aadhar+"','"+Scheme_Name+"','"+Scheme_Details+"','"+Date_From+"','"+Date_To+"')";
		int i=stmt.executeUpdate(s);
		System.out.println(i+" Record Added");
		RequestDispatcher rd =request.getRequestDispatcher("submit.html");
		rd.forward(request,response);
		
		con.close();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		}

}
